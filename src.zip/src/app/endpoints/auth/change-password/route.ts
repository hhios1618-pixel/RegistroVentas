// Proxy para mantener /endpoints/auth/change-password
export { POST } from '../auth/change-password/route';