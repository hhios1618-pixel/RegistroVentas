import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { sign } from 'jsonwebtoken';

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const JWT_SECRET = process.env.JWT_SECRET!;

// Cliente de Supabase (server-side)
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export async function POST(request: Request) {
  if (!JWT_SECRET) {
    console.error('JWT_SECRET no está definido');
    return NextResponse.json({ error: 'Error de configuración.' }, { status: 500 });
  }

  try {
    // Ahora aceptamos "identifier" (puede ser username o email)
    const { identifier, email, password } = await request.json();

    // Soportamos ambos payloads: {identifier, password} o {email, password}
    const provided = (identifier ?? email)?.toString().trim();
    if (!provided || !password) {
      return NextResponse.json({ error: 'Usuario/Email y contraseña son requeridos.' }, { status: 400 });
    }

    // Resolver a email real:
    let loginEmail = provided;

    if (!provided.includes('@')) {
      // Es un username → buscamos su email en people
      const { data: personByUser, error: personByUserErr } = await supabase
        .from('people')
        .select('email')
        .eq('username', provided)
        .single();

      if (personByUserErr || !personByUser?.email) {
        return NextResponse.json({ error: 'Usuario no encontrado.' }, { status: 401 });
      }

      loginEmail = personByUser.email;
    }

    // Validar credenciales con Supabase Auth (fuente de la verdad)
    const { data: authRes, error: authErr } = await supabase.auth.signInWithPassword({
      email: loginEmail,
      password,
    });

    if (authErr || !authRes?.user) {
      return NextResponse.json({ error: 'Credenciales inválidas.' }, { status: 401 });
    }

    // Cargar datos de la persona (nombre/rol/etc.) para el payload del JWT propio
    const { data: person, error: personErr } = await supabase
      .from('people')
      .select('id, email, full_name, role, username, auth_user_id')
      .eq('email', loginEmail)
      .single();

    if (personErr || !person) {
      return NextResponse.json({ error: 'Perfil no encontrado.' }, { status: 404 });
    }

    const userPayload = {
      id: person.id,
      email: person.email,
      name: person.full_name,
      role: person.role,
      username: person.username,
      auth_user_id: person.auth_user_id ?? authRes.user.id,
    };

    const token = sign(userPayload, JWT_SECRET, { expiresIn: '7d' });

    const res = NextResponse.json({ message: 'Login exitoso', user: userPayload });

    res.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7, // 7 días
      path: '/',
    });

    return res;
  } catch (err) {
    console.error('Error en login:', err);
    return NextResponse.json({ error: 'Ocurrió un error inesperado.' }, { status: 500 });
  }
}